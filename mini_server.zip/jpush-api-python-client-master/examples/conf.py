app_key = u'2970f54c65d418342abe363d'
master_secret = u'3c078d59810f429a492de01e'
