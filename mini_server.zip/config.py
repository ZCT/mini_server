#coding:utf-8
__author__ = 'cocotang'


SQLALCHEMY_DATABASE_URI='mysql://root:onepiece9@10.66.106.13/coco?charset=utf8'

PUSH_APP_KEY = u'e9adae5ab5aeb524d00c2c8c'
PUSH_MASTER_SECRET = u'd947444786f72ac0fc00f550'

UPLOAD_DIR_ROOT='/home/coco/data/'
UPLOAD_SLASH='/'
UPLOAD_ALARM_FOLDER='static/alarms/'
UPLOAD_PROFILE_FOLDER='static/profile_pic/'
UPLOAD_PICTURE_FOLDER='static/picture/'
UPLOAD_MINIPIC_FOLDER='static/minipic/'
UPLOAD_VOICE_FOLDER='static/voice/'


ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'amr'])